#ifndef __AUX_METHODS_H
#define __AUX_METHODS_H

#include "header.h"
#include "parameter.h"

double get_power(double, int);
ll getnCr(int, int);

ppi get_split(int);

void validation();

#endif // __AUX_METHODS_H
