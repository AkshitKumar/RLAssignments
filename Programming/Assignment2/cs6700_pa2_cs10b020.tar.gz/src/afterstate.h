#ifndef __AFTERSTATE_H
#define __AFTERSTATE_H

#include "state.h"
#include "parameter.h"

class afterstate : public state{
  public:
    afterstate(int, int, int);
};
#endif // ___AFTERSTATE_H
